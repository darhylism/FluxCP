<?php
require_once 'Flux/BaseServer.php';

/**
 * Represents an rAthena Character Server.
 */
class Flux_CharServer extends Flux_BaseServer {
	
}
?>
