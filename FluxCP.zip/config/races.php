<?php
// rA monster races.
return array(
	 0 => 'Formless',
	 1 => 'Undead',
	 2 => 'Brute',
	 3 => 'Plant',
	 4 => 'Insect',
	 5 => 'Fish',
	 6 => 'Demon',
	 7 => 'Demi-Human',
	 8 => 'Angel',
	 9 => 'Dragon',
	10 => 'Human'
)
?>
