<?php
return array(
	'modules' => array(
		'helloworld' => array(
			'index' => AccountLevel::ADMIN
		)
	),
	'features' => array(
		// None.
	)
)
?>
