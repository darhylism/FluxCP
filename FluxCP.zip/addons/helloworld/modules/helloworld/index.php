<?php
if (!defined('FLUX_ROOT')) exit;

$fluxVersion  = Flux::VERSION;
$fluxVersion .= Flux::REPOSVERSION ? '.'.Flux::REPOSVERSION : '';
?>
