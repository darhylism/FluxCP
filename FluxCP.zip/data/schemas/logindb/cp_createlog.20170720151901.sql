ALTER TABLE `cp_createlog` CHANGE `reg_date` `reg_date` DATETIME NOT NULL;
