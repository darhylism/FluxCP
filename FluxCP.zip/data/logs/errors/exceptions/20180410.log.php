<?php exit('Forbidden'); ?>
[2018-04-10 08:52:11] (PDOException) Exception PDOException: SQLSTATE[HY000] [2003] Can't connect to MySQL server on '162.248.93.81' (113)
[2018-04-10 08:52:11] (PDOException) **TRACE** #0 /home/mayaanro/public_html/cp/lib/Flux/Template.php(375): include()
[2018-04-10 08:52:11] (PDOException) **TRACE** #1 /home/mayaanro/public_html/cp/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2018-04-10 08:52:11] (PDOException) **TRACE** #2 /home/mayaanro/public_html/cp/index.php(177): Flux_Dispatcher->dispatch(Array)
[2018-04-10 08:52:11] (PDOException) **TRACE** #3 {main}
[2018-04-10 08:53:17] (PDOException) Exception PDOException: SQLSTATE[HY000] [2003] Can't connect to MySQL server on '162.248.93.81' (113)
[2018-04-10 08:53:17] (PDOException) **TRACE** #0 /home/mayaanro/public_html/cp/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=162....', 'root', '4UGVpcyufGmqKqP...', Array)
[2018-04-10 08:53:17] (PDOException) **TRACE** #1 /home/mayaanro/public_html/cp/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2018-04-10 08:53:17] (PDOException) **TRACE** #2 /home/mayaanro/public_html/cp/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2018-04-10 08:53:17] (PDOException) **TRACE** #3 /home/mayaanro/public_html/cp/modules/character/online.php(79): Flux_Connection->getStatement('SELECT COUNT(ch...')
[2018-04-10 08:53:17] (PDOException) **TRACE** #4 /home/mayaanro/public_html/cp/lib/Flux/Template.php(375): include('/home/mayaanro/...')
[2018-04-10 08:53:17] (PDOException) **TRACE** #5 /home/mayaanro/public_html/cp/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2018-04-10 08:53:17] (PDOException) **TRACE** #6 /home/mayaanro/public_html/cp/index.php(177): Flux_Dispatcher->dispatch(Array)
[2018-04-10 08:53:17] (PDOException) **TRACE** #7 {main}
