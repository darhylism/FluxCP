<?php exit('Forbidden'); ?>
[2018-07-23 15:43:28] (Flux_LoginError) Exception Flux_LoginError: IP address is banned
[2018-07-23 15:43:28] (Flux_LoginError) **TRACE** #0 /home/mayaanro/public_html/cp/modules/account/create.php(75): Flux_SessionData->login('Mayaan Server', 'jhayheadz1', 'Meowmeow123', false)
[2018-07-23 15:43:28] (Flux_LoginError) **TRACE** #1 /home/mayaanro/public_html/cp/lib/Flux/Template.php(375): include('/home/mayaanro/...')
[2018-07-23 15:43:28] (Flux_LoginError) **TRACE** #2 /home/mayaanro/public_html/cp/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2018-07-23 15:43:28] (Flux_LoginError) **TRACE** #3 /home/mayaanro/public_html/cp/index.php(195): Flux_Dispatcher->dispatch(Array)
[2018-07-23 15:43:28] (Flux_LoginError) **TRACE** #4 {main}
