<?php exit('Forbidden'); ?>
[2018-03-31 07:14:42] (PDOException) Exception PDOException: SQLSTATE[HY000] [2013] Lost connection to MySQL server at 'reading authorization packet', system error: 0
[2018-03-31 07:14:42] (PDOException) **TRACE** #0 /home/mayaanro/public_html/cp/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=162....', 'root', '4UGVpcyufGmqKqP...', Array)
[2018-03-31 07:14:42] (PDOException) **TRACE** #1 /home/mayaanro/public_html/cp/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2018-03-31 07:14:42] (PDOException) **TRACE** #2 /home/mayaanro/public_html/cp/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2018-03-31 07:14:42] (PDOException) **TRACE** #3 /home/mayaanro/public_html/cp/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2018-03-31 07:14:42] (PDOException) **TRACE** #4 /home/mayaanro/public_html/cp/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'manggekyu016')
[2018-03-31 07:14:42] (PDOException) **TRACE** #5 /home/mayaanro/public_html/cp/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2018-03-31 07:14:42] (PDOException) **TRACE** #6 /home/mayaanro/public_html/cp/index.php(149): Flux_SessionData->__construct(Array, false)
[2018-03-31 07:14:42] (PDOException) **TRACE** #7 {main}
