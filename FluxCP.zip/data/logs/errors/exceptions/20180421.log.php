<?php exit('Forbidden'); ?>
[2018-04-21 04:17:40] (PDOException) Exception PDOException: SQLSTATE[HY000] [2013] Lost connection to MySQL server at 'reading authorization packet', system error: 0
[2018-04-21 04:17:40] (PDOException) **TRACE** #0 /home/mayaanro/public_html/cp/lib/Flux/Template.php(375): include()
[2018-04-21 04:17:40] (PDOException) **TRACE** #1 /home/mayaanro/public_html/cp/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2018-04-21 04:17:40] (PDOException) **TRACE** #2 /home/mayaanro/public_html/cp/index.php(177): Flux_Dispatcher->dispatch(Array)
[2018-04-21 04:17:40] (PDOException) **TRACE** #3 {main}
