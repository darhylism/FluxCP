<?php exit('Forbidden'); ?>
[2018-09-27 08:38:29] (PDOException) Exception PDOException: SQLSTATE[HY000] [2003] Can't connect to MySQL server on '162.248.93.81' (110)
[2018-09-27 08:38:29] (PDOException) **TRACE** #0 /home/mayaanro/public_html/cp/lib/Flux/Template.php(375): include()
[2018-09-27 08:38:29] (PDOException) **TRACE** #1 /home/mayaanro/public_html/cp/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2018-09-27 08:38:29] (PDOException) **TRACE** #2 /home/mayaanro/public_html/cp/index.php(195): Flux_Dispatcher->dispatch(Array)
[2018-09-27 08:38:29] (PDOException) **TRACE** #3 {main}
