<?php exit('Forbidden'); ?>
[2018-04-05 07:06:08] (PDOException) Exception PDOException: SQLSTATE[HY000] [2013] Lost connection to MySQL server at 'waiting for initial communication packet', system error: 110
[2018-04-05 07:06:08] (PDOException) **TRACE** #0 /home/mayaanro/public_html/cp/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=162....', 'root', '4UGVpcyufGmqKqP...', Array)
[2018-04-05 07:06:08] (PDOException) **TRACE** #1 /home/mayaanro/public_html/cp/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2018-04-05 07:06:08] (PDOException) **TRACE** #2 /home/mayaanro/public_html/cp/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2018-04-05 07:06:08] (PDOException) **TRACE** #3 /home/mayaanro/public_html/cp/lib/Flux/TemporaryTable.php(242): Flux_Connection->getStatement('DROP TEMPORARY ...')
[2018-04-05 07:06:08] (PDOException) **TRACE** #4 /home/mayaanro/public_html/cp/lib/Flux/TemporaryTable.php(97): Flux_TemporaryTable->drop()
[2018-04-05 07:06:08] (PDOException) **TRACE** #5 /home/mayaanro/public_html/cp/lib/Flux/TemporaryTable.php(72): Flux_TemporaryTable->create('ragnarok.item_d...')
[2018-04-05 07:06:08] (PDOException) **TRACE** #6 /home/mayaanro/public_html/cp/modules/item/view.php(14): Flux_TemporaryTable->__construct(Object(Flux_Connection), 'ragnarok.items', Array)
[2018-04-05 07:06:08] (PDOException) **TRACE** #7 /home/mayaanro/public_html/cp/lib/Flux/Template.php(375): include('/home/mayaanro/...')
[2018-04-05 07:06:08] (PDOException) **TRACE** #8 /home/mayaanro/public_html/cp/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2018-04-05 07:06:08] (PDOException) **TRACE** #9 /home/mayaanro/public_html/cp/index.php(177): Flux_Dispatcher->dispatch(Array)
[2018-04-05 07:06:08] (PDOException) **TRACE** #10 {main}
