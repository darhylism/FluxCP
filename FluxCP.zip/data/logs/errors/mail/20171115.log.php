<?php exit('Forbidden'); ?>
