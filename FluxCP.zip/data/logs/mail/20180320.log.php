<?php exit('Forbidden'); ?>
[2018-03-20 00:57:18] sent e-mail -- Recipient: josiahcostales@gmail.com, Subject: Reset Password
[2018-03-20 00:58:01] sent e-mail -- Recipient: josiahcostales@gmail.com, Subject: Password Has Been Reset
[2018-03-20 01:07:44] sent e-mail -- Recipient: josiahcostales@gmail.com, Subject: Reset Password
[2018-03-20 01:08:30] sent e-mail -- Recipient: josiahcostales@gmail.com, Subject: Password Has Been Reset
