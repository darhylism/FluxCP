<?php exit('Forbidden'); ?>
[2018-04-27 11:05:05] sent e-mail -- Recipient: wizard_boy52@yahoo.com , Subject: Reset Password
[2018-04-27 11:08:25] sent e-mail -- Recipient: conradng01@gmail.com, Subject: Reset Password
[2018-04-27 11:09:24] sent e-mail -- Recipient: conradng01@gmail.com, Subject: Password Has Been Reset
