<?php exit('Forbidden'); ?>
[2018-08-13 14:08:27] sent e-mail -- Recipient: xurukiorashifa@gmail.com, Subject: Reset Password
[2018-08-13 14:08:54] sent e-mail -- Recipient: xurukiorashifa@gmail.com, Subject: Password Has Been Reset
