<?php exit('Forbidden'); ?>
[2018-05-24 07:43:28] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Reset Password
[2018-05-24 07:43:36] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Password Has Been Reset
