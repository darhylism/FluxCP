<?php exit('Forbidden'); ?>
[2018-05-17 06:20:31] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Reset Password
[2018-05-17 06:21:02] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Password Has Been Reset
[2018-05-17 06:22:10] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Reset Password
[2018-05-17 06:22:32] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Password Has Been Reset
[2018-05-17 06:35:49] sent e-mail -- Recipient: jaypeestarrrrrr@yahoo.com, Subject: Reset Password
[2018-05-17 06:36:00] sent e-mail -- Recipient: jaypeestarrrrrr@yahoo.com, Subject: Reset Password
[2018-05-17 06:39:25] sent e-mail -- Recipient: jaypeestarrrrrr@yahoo.com, Subject: Reset Password
