<?php exit('Forbidden'); ?>
[2018-05-21 10:10:05] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Reset Password
[2018-05-21 10:10:29] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Password Has Been Reset
