<?php exit('Forbidden'); ?>
[2018-07-22 17:01:19] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Reset Password
[2018-07-22 17:01:27] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Password Has Been Reset
