<?php exit('Forbidden'); ?>
[2018-03-11 04:39:48] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Reset Password
[2018-03-11 04:41:16] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Password Has Been Reset
[2018-03-11 04:46:19] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Reset Password
[2018-03-11 04:47:00] sent e-mail -- Recipient: aaron.aguilar.wat2017@gmail.com, Subject: Password Has Been Reset
