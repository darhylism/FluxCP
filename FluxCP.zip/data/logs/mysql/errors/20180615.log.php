<?php exit('Forbidden'); ?>
[2018-06-15 08:18:14] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2018-06-15 09:25:42] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
