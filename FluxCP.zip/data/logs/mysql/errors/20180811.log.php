<?php exit('Forbidden'); ?>
[2018-08-11 20:11:59] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2018-08-11 20:28:24] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#VOTEPOINTS' AND account_id = '2000000'' at line 1
[2018-08-11 20:31:10] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#VOTEPOINTS' AND account_id = '2000000'' at line 1
[2018-08-11 20:31:10] [SQLSTATE=23000] Err 1062: Duplicate entry '2000000-#VOTEPOINTS-0' for key 'PRIMARY'
[2018-08-11 20:31:37] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#VOTEPOINTS' AND account_id = '2000000'' at line 1
[2018-08-11 20:31:37] [SQLSTATE=23000] Err 1062: Duplicate entry '2000000-#VOTEPOINTS-0' for key 'PRIMARY'
[2018-08-11 20:37:40] [SQLSTATE=42S22] Err 1054: Unknown column 'str' in 'where clause'
[2018-08-11 20:37:40] [SQLSTATE=23000] Err 1062: Duplicate entry '2000000-#VOTEPOINTS-0' for key 'PRIMARY'
