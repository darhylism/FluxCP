<?php exit('Forbidden'); ?>
[2018-02-28 03:00:12] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2018-02-28 03:00:19] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2018-02-28 03:00:52] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2018-02-28 22:50:07] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
