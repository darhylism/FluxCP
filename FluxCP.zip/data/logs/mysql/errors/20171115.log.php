<?php exit('Forbidden'); ?>
[2017-11-15 02:38:44] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2017-11-15 02:51:58] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2017-11-15 13:26:42] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2017-11-15 21:06:35] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2017-11-15 21:07:34] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
