<?php exit('Forbidden'); ?>
[2017-11-26 15:04:48] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2017-11-26 15:04:53] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2017-11-26 15:05:37] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2017-11-26 15:06:06] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
[2017-11-26 15:06:20] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'key = '#CASHPOINTS'' at line 1
